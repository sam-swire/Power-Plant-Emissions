import pandas as pd

from tools.display_dataframe import display_dataframe

### Used to decide how many rows to display in the output
pd.set_option('display.max_rows', 10)
pd.set_option('display.width', 10000)

import os, uuid
from typing import Optional, Type
from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field, ConfigDict
from langchain_core.tools import InjectedToolArg
from typing_extensions import Annotated

from langchain_core.callbacks import CallbackManagerForToolRun
from langchain_community.graphs import Neo4jGraph
from func_timeout import func_timeout, FunctionTimedOut

def format_schema(schema):
    output = []
    
    output.append("Node properties:")
    for node, details in schema['nodes'].items():
        output.append(f" - **{node}**")
        for prop in details['properties']:
            output.append(f"   - `{prop['property']}`: Description: {prop['type']} {prop['description']}")

    # Relationship properties
    output.append("\nRelationship properties:")
    for rel in schema['relationships']:
        if 'properties' in rel:
            output.append(f" - **{rel['type']}**")
            for prop in rel['properties']:
                output.append(f"   - `{prop['property']}: {prop['type']}`")

    output.append("\nThe relationships:")
    for rel in schema['relationships']:
        output.append(f" - `(:{rel['start']})-[:{rel['type']}]->(:{rel['end']})`: Description: {rel['description']}")
    return "\n".join(output)


class BaseNeo4jDatabaseTool(BaseModel):
	graph: Neo4jGraph = Field(exclude=True)
	model_config = ConfigDict(
		arbitrary_types_allowed=True,
	)

class Neo4jQueryInput(BaseModel):
	query: str = Field(..., description="A detailed and correct Cypher query.")
class Neo4jQueryTool(BaseNeo4jDatabaseTool, BaseTool):
	"""Tool for querying a Neo4j database."""
	name: str = "neo4j_query"
	description: str = """
	Function: Executes a Cypher query against Neo4j DB. 
	Input: A valid Cypher query compatible with Neo4j dialect.
	Output: The head rows of result table and table path. 
	Dependencies:
	1. Use `neo4j_get_schema` to retrieve the schema of all related tables.
	2. Use `search_name` to search the exact name of all fields or institutions.
	Note: All IDs in this database are string type. 
	"""
	args_schema: Type[BaseModel] = Neo4jQueryInput

	### Parameters ###
	session_id: str = "test"

	timeout: int = 120

	workspace: str = "data/output"
	display_mode: str = "markdown"
	display_rows: int = 20
	demical_precision: int = 4

	def remove_group_by(self, query: str) -> str:
		return '\n'.join([i for i in query.split('\n') if 'GROUP BY' not in i])

	def _run(self, query: str):
		# cypher = self.remove_group_by(cypher)
		response = {}
		try:
			df = pd.DataFrame(func_timeout(self.timeout, self.graph.query, args=(query,))).round(self.demical_precision)
			df_string = display_dataframe(
				df, mode=self.display_mode,
				display_rows=self.display_rows, 
				decimal_precision=self.demical_precision
			)

			response['response'] = df_string

			file_name = f"{(uuid.uuid4())}.csv"
			file_path = f"{self.workspace}/{file_name}"

			df.to_csv(file_path, index=False)
			response["file"] = file_path

		except (Exception, FunctionTimedOut) as e:
			response['response'] = f"{type(e).__name__}: {str(e)}"
		return response


import json
class Neo4jGetSchemaTool(BaseModel):
	query: str = Field("", description="An empty string")
class Neo4jGetSchemaTool(BaseNeo4jDatabaseTool, BaseTool):
	name: str = "neo4j_get_schema"
	description: str = """
	Function: Retrieves schema for Neo4j database. 
	Input: An empty string. 
	Output: detailed schema of the database, including nodes, relationships, and properties.
	"""
	args_schema: Type[BaseModel] = Neo4jGetSchemaTool

	def _run(self, query: str = "") -> str:
		response = {}

		try:
			response['response'] = format_schema(json.load(open("enriched_schema.json")))
			return response
		except Exception as e:
			response['response'] = "{}: {}".format(type(e).__name__, str(e))
			return response


# from langchain_community.graphs import Neo4jGraph
# graph = Neo4jGraph(
# 	url=os.getenv("NEO4J_URL"), username="xxxxxxxxx", password="xxxxxxxxx", 
# 	sanitize=False, refresh_schema=False, enhanced_schema=False
# )

# neo4j_get_schema_tool = Neo4jGetSchemaTool(graph=graph)
# neo4j_query_tool = Neo4jQueryTool(graph=graph)