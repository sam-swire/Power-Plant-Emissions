from typing import Optional, Type
from langchain.tools import BaseTool
from langchain_core.vectorstores import VectorStore
from langchain_core.output_parsers import JsonOutputParser
from prompts.prompts import HyDE_post_retrieval, HyDE_pre_retrieval, HyDE_post_retrieval_xml
from langchain_core.language_models import BaseChatModel

from pydantic import BaseModel, Field
import pandas as pd
import json


from dotenv import load_dotenv
load_dotenv()


from langchain_core.output_parsers import JsonOutputParser
from prompts.prompts import HyDE_pre_retrieval, HyDE_post_retrieval
def pre_retrieval_processing(llm_json, x, section_type):
	PreRetrievalChain = HyDE_pre_retrieval| llm_json | JsonOutputParser()
	hypo_y = PreRetrievalChain.invoke({"query": x, "section_type": section_type})
	return list(hypo_y.values())

def post_retrieval_processing(llm_json, query, section_type, y):
	PostRetrievalChain = HyDE_post_retrieval | llm_json | JsonOutputParser()
	y2 = PostRetrievalChain.invoke({"query": query, "section_type": section_type, "search_results": y})
	y3 = y2["summary"] + "\n\nReferences:\n"
	for ref in y2["references"]:
		doi = ref.get("doi", "")
		if doi:
			y3 += f"\n{ref['id']}. [{ref['ref']}]({ref['doi']})"
		else:
			y3 += f"\n{ref['id']}. {ref['ref']}"
	return y3


def post_retrieval_processing_xml(llm, query, search_results):
	"""Process search results into XML format literature review"""
	response = llm.invoke(HyDE_post_retrieval_xml.invoke({
		"query": query,
		"search_results": search_results
	})).content
	
	# Extract content between XML tags
	import re
	references_match = re.search(r'<references>(.*?)</references>', response, re.DOTALL)
	summary_match = re.search(r'<summary>(.*?)</summary>', response, re.DOTALL)
	
	if not references_match or not summary_match:
		raise ValueError("Invalid XML format in response")
		
	references = references_match.group(1).strip()
	summary = summary_match.group(1).strip()
	
	# Format output with references as markdown links where possible
	formatted_refs = []
	for ref_match in re.finditer(r'<reference>(.*?)</reference>', references, re.DOTALL):
		ref = ref_match.group(1)
		id_match = re.search(r'<id>(.*?)</id>', ref)
		ref_text_match = re.search(r'<ref>(.*?)</ref>', ref) 
		doi_match = re.search(r'<doi>(.*?)</doi>', ref)
		
		if id_match and ref_text_match:
			ref_id = id_match.group(1).strip().replace('[', '').replace(']', '')
			ref_text = ref_text_match.group(1).strip()
			doi = doi_match.group(1).strip() if doi_match else ""
			
			if doi:
				formatted_refs.append(f"{ref_id}. [{ref_text}]({doi})")
			else:
				formatted_refs.append(f"{ref_id}. {ref_text}")

	summary = [i.strip() for i in summary.split("\n") if i.strip()]
	response = "\n\n".join(summary) + "\n\nReferences:\n" + "\n".join(formatted_refs)
	print(response)
	return response



def __format_output_df_as_prompt__(df):
	prompt = []
	for index, row in df.iterrows():
		authors = ', '.join(row['authors'][:-1]) + ', and ' + row['authors'][-1] if len(row['authors']) > 1 else row['authors'][0]

		ref = f"{authors}. " + row.filename.replace('.pdf', '')
		text = row['section_text']
		section_info = f"Section {row['section_id']}: {row['section_type']}"
		prompt.append({"ref": ref, "section": section_info, "text": text})
	prompt = json.dumps(prompt, indent=4)
	return prompt

def __search_and_format__(PVS, search_keywords, k=3, section_type=None, authors=None, section_id=None, paper_title=None, venue=None):
	filter_conditions = []
	if authors:
		filter_conditions.append({"authors": {"$in": authors}})
	if section_type:
		filter_conditions.append({"section_type": section_type})
	if section_id:
		filter_conditions.append({"section_id": section_id})
	if paper_title:
		filter_conditions.append({"paper_title": paper_title})
	if venue:
		filter_conditions.append({"venue": venue})
	filter_query = {"$and": filter_conditions} if filter_conditions else None
	
	if type(search_keywords) == str:
		search_keywords = [search_keywords]

	df = []
	for search_keyword in search_keywords:
		output = PVS.similarity_search(search_keyword, filter=filter_query, k=k)
		df_temp = pd.DataFrame([i.metadata | {'section_text': i.page_content} for i in output])
		# df_temp.authors = df_temp.authors.apply(lambda x: ', '.join(x[:-1]) + ', and ' + x[-1] if len(x) > 1 else x[0])
		df.append(df_temp)
	df = pd.concat(df, ignore_index=True)
	
	if df.shape[0] > 0:
		output = df.sort_values(['paper_title', 'section_id']).drop_duplicates(['paper_title', 'section_id']).reset_index(drop=True)
		formatted_prompt = __format_output_df_as_prompt__(output)
	else:
		formatted_prompt = "No search results found."
	return formatted_prompt



from typing import Literal
class SearchLiteratureAdvancedInput(BaseModel):
	query: str = Field(..., 
		description="The search query to find relevant papers and sections in the SciSci literature")
	k: int = Field(10, 
		description="A larger value provides more results", ge=1)
	section: Literal["All", "Abstract", "Introduction", "Related Works", "Methodology", "Results", "Discussion", "Conclusion", "Appendix", "Acknowledgement"] = Field(..., 
		description="Filter results to only of a specific section (`All` for all sections)")
	title: Optional[str] = Field(None, 
		description="Filter results to only include sections from a specific paper title")
	authors: Optional[list[str]] = Field(None, 
		description="Filter results to only include papers written by any of these authors")
	section_id: Optional[str] = Field(None, 
		description="Filter results to only include a specific section ID from papers")
	venue: Optional[str] = Field(None, 
		description="Filter results to only include papers published in a specific venue/journal")

class SearchLiteratureAdvancedTool(BaseTool):
	name: str = "search_literature"
	description: str = """
	Function: Performs an advanced semantic search across Science of Science literature to find relevant papers and sections.
	Output: A comprehensive literature review with:
	- Relevant paper sections and quotes
	- Full citations with author names
	- DOI links when available
	- Contextual summary connecting the results to the query
	Note: This tool specializes in Science of Science literature only.
	"""
	args_schema: Type[BaseModel] = SearchLiteratureAdvancedInput
	vectorstore: VectorStore
	llm_json: BaseChatModel

	def _run(self, query: str, k: int = 10, section: str = None, title: str = None, authors: list = None, 
			 section_id: str = None, venue: str = None):
		response = {}
		try:
			section = section if section != "All" else None
			# hypo_ys = pre_retrieval_processing(self.llm_json, query, section_type)
			hypo_ys = [ query ]
			y = __search_and_format__(self.vectorstore, hypo_ys, k, section, authors, section_id, title, venue)
			if y == "No search results found.":
				response['response'] = y
			else:
				response['response'] = post_retrieval_processing_xml(self.llm_json, query, y)
		except Exception as e:
			response['response'] = "{}: {}".format(type(e).__name__, str(e))
		finally:
			return response

class SearchLiteratureVanillaInput(BaseModel):
	query: str = Field(..., description="The search term")
	k: int = Field(3, description="Number of results to return")
	section_type: Optional[str] = Field(None, description="Type of section to search in")
	# authors: Optional[list] = Field(None, description="List of authors to filter by")
	# section_id: Optional[str] = Field(None, description="Section ID to filter by")
	# paper_title: Optional[str] = Field(None, description="Paper title to filter by")
	# venue: Optional[str] = Field(None, description="Venue to filter by")

class SearchLiteratureVanillaTool(BaseTool):
	name: str = "search_literature_vanilla"
	description: str = """
	Function: Performs a search for literature of the Science of Science.
	Input:
	- query: The main search term (required)
	- k: Number of results to return (default: 3)
	- section_type: Type of paper section to search in (optional)
	Output: A formatted list of search results including paper details and relevant text sections.
	"""
	args_schema: Type[BaseModel] = SearchLiteratureVanillaInput
	vectorstore: VectorStore

	def _run(
		self, query: str, k: int = 3, section_type: str = None, 
		authors: list = None, section_id: str = None, 
		paper_title: str = None, venue: str = None
	):
		response = {}
		try:
			response['response'] = __search_and_format__(self.vectorstore, query, k, section_type, authors, section_id, paper_title, venue)
		except Exception as e:
			response['response'] = "{}: {}".format(type(e).__name__, str(e))
		finally:
			return response


# Initialize tools
from langchain_pinecone import PineconeVectorStore
from langchain_openai import OpenAIEmbeddings
from langchain_openai import ChatOpenAI
# llm_json = ChatOpenAI(
# 	model="gpt-4-turbo", temperature=0, 
# 	model_kwargs={"response_format":{"type": "json_object"}}, 
# 	streaming=False, disable_streaming=True
# )


from langchain_google_vertexai.model_garden import ChatAnthropicVertex
# Initialise the Model
llm_json = ChatAnthropicVertex(
	model_name="claude-3-5-haiku@20241022", 
	project="ksm-rch-sciscigpt", 
	location="us-east5", 
	temperature=0.5, max_output_tokens=8192, disable_streaming=True
)


literature_vectorstore = PineconeVectorStore.from_existing_index(
	embedding=OpenAIEmbeddings(model="text-embedding-3-large"),
	index_name="scisci-papers"
)

search_literature_advanced_tool = SearchLiteratureAdvancedTool(vectorstore=literature_vectorstore, llm_json=llm_json)
search_literature_vanilla_tool = SearchLiteratureVanillaTool(vectorstore=literature_vectorstore)