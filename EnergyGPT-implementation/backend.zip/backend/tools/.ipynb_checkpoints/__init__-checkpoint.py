##### Data Extraction Tools
from tools.sql import SQLListTableTool, SQLGetSchemaTool, SQLQueryTool
from tools.gensci_literature import GenSciLiteratureRetrievalTool
from langchain_community.utilities import SQLDatabase
import os


from dotenv import load_dotenv
load_dotenv()

bigquery_uri = os.getenv("GOOGLE_BIGQUERY_URI")
db_name = bigquery_uri.split("/")[-1]
# Initialize tools
db_dict = {
	db_name: SQLDatabase.from_uri(
		database_uri=bigquery_uri, 
		sample_rows_in_table_info=0, 
	)
}

sql_list_table_tool = SQLListTableTool(db_dict=db_dict)
sql_get_schema_tool = SQLGetSchemaTool(db_dict=db_dict)
sql_query_tool = SQLQueryTool(db_dict=db_dict)

gen_sci_literature_tool = GenSciLiteratureRetrievalTool(db_dict=db_dict)


# from tools.neo4j import neo4j_get_schema_tool, neo4j_query_tool
from tools.name import search_name_tool

##### Data Analysis Tools
from tools.sandbox import python_shell_tool #, r_shell_tool

##### Literature Review
from tools.literature import search_literature_vanilla_tool, search_literature_advanced_tool

##### External Data
from tools.arxiv import arxiv_query_tool
# from tools.google_search import google_search_tool
from tools.openalex import openalex_query_tool


tools = [
    sql_list_table_tool, sql_get_schema_tool, sql_query_tool, 
	# neo4j_get_schema_tool, neo4j_query_tool, 
    search_name_tool, 
	python_shell_tool, #r_shell_tool, 
    search_literature_vanilla_tool, search_literature_advanced_tool, gen_sci_literature_tool
	# arxiv_query_tool, google_search_tool, openalex_query_tool,
]

enabled_tools = [
    sql_list_table_tool, sql_get_schema_tool, sql_query_tool, 
    python_shell_tool, search_name_tool, #r_shell_tool, search_name_tool, 
    # neo4j_get_schema_tool, neo4j_query_tool, 
    search_literature_advanced_tool, gen_sci_literature_tool
]