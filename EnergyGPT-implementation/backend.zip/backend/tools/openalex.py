from tools.display_dataframe import display_dataframe
import uuid, json
from requests import get
import pandas as pd
from langchain.tools import BaseTool
from pydantic import BaseModel, Field
from typing import Any, Dict, Optional, Sequence, Type, Union
from langchain_core.tools import InjectedToolArg
from typing_extensions import Annotated


class OpenAlexQueryInput(BaseModel):
	url: str = Field(..., description="A valid OpenAlex Query URL.")
	session_id: Annotated[str, InjectedToolArg] = Field(..., description="Session ID")


class OpenAlexQueryTool(BaseTool):
	name: str = "openalex_query"
	description: str = "Query OpenAlex API and return results as a dataframe or JSON response."
	args_schema: Type[BaseModel] = OpenAlexQueryInput

	filename: str = None
	workspace: str = "data/output"
	display_mode: str = "markdown"
	display_rows: int = 10
	decimal_precision: int = 4

	def _run(self, url: str, session_id: str) -> str:
		"""
		Query OpenAlex API.
		"""
		openalex_response = get(url)
		status_code = openalex_response.status_code
		content = openalex_response.json()

		response = {}
		if status_code == 200:
			if 'results' in content:
				df = pd.DataFrame(content['results'])
				df_string = display_dataframe(
					df, mode=self.display_mode,
					display_rows=self.display_rows, 
					decimal_precision=self.decimal_precision
				)

				file_name = self.filename if self.filename else f"{(uuid.uuid4())}.parquet"
				file_path = f"{self.workspace}/{file_name}"
				response['file_path'] = file_path
				df.to_parquet(file_path, index=False)
			else:
				df_string = content
				
			response['response'] = df_string
		else:
			response['response'] = content

		return (json.dumps(response, indent=4), status_code)

openalex_query_tool = OpenAlexQueryTool()