from langchain.tools import BaseTool
from pydantic import BaseModel, Field
from typing import Any, Type, List
from typing_extensions import Annotated
from langchain_core.tools import InjectedToolArg
import arxiv, uuid, json

from langchain_core.output_parsers import JsonOutputParser
from langchain_openai import ChatOpenAI
llm_json = ChatOpenAI(model="gpt-4-turbo", temperature=0, model_kwargs={"response_format":{"type": "json_object"}})

import pandas as pd
from langchain.prompts import ChatPromptTemplate
HyDE_post_retrieval_arxiv = ChatPromptTemplate([
    ("system", """You are an AI assistant specializing in summarizing scientific literature. Your task is to create a detailed, informative literature review based on search results."""),
    ("human", """Analyze the following query and search results to produce a brief literature review summary:

Query: {query}
Search Results:
{search_results}

Instructions:
1. Synthesize the information into a single coherent paragraph of about 200 words.
2. Highlight key findings and their relevance to the query.
3. Each paper should be summarized as a separate sentence.
3. Use in-text citations [id] to link claims to specific papers.
4. Provide a list of references used in the summary.
     
Provide the summary in this JSON format:
{{
     "references": [
        {{
            "id": INTEGER: id of the paper,
            "title": STRING: title of the paper,
            "url": STRING: paper's url
        }},
        // ... additional references ...
        // Each paper should only appear once in the list. The reference id should start with [1] and increment by 1 for each additional reference.
    ],
    "summary": "Your detailed literature review paragraph here, using [id] for citations."
}}
""")
])

# llm_json = ChatOpenAI(model="gpt-4-turbo", temperature=0, model_kwargs={"response_format":{"type": "json_object"}})
def post_retrieval_processing_arxiv(llm_json, query, y):
	PostRetrievalChain = HyDE_post_retrieval_arxiv | llm_json | JsonOutputParser()
	y2 = PostRetrievalChain.invoke({"query": query, "search_results": y})
	y3 = y2["summary"] + "\n\nReferences:\n"
	for ref in y2["references"]:
		title = ref.get("title", "")
		if title:
			y3 += f"\n{ref['id']}. [{ref['title']}]({ref['url']})"
		else:
			y3 += f"\n{ref['id']}. {ref['url']}"
	return y3
class ArxivQueryInput(BaseModel):
    query: str = Field(..., description="The search query for Arxiv.")
    max_results: int = Field(10, description="The maximum number of results to return.")
    session_id: Annotated[str, InjectedToolArg] = Field(..., description="Session ID")
    sort_by: str = Field("SubmittedDate", description="Sort criterion (SubmittedDate, Relevance, LastUpdatedDate).")

class ArxivQueryTool(BaseTool):
    name: str = "arxiv_query"
    description: str = "Query Arxiv and return results as a dataframe or JSON response."
    args_schema: Type[BaseModel] = ArxivQueryInput

    filename: str = None
    workspace: str = "data/output"
    display_mode: str = "markdown"
    display_rows: int = 10
    decimal_precision: int = 4
    def _run(self, query: str, session_id: str, max_results: int = 10, sort_by: str = "SubmittedDate") -> str:
        """
        Query Arxiv API.
        """
        # Construct the Arxiv client
        print('!!!!!!!!!!!query is :', query, '!!!!!!!!!!!')
        client = arxiv.Client()
        # Define the search query
        search = arxiv.Search(
            query=query,
            max_results=max_results,
            sort_by=arxiv.SortCriterion[sort_by]
        )

        # Get results from the search
        results = client.results(search)
        all_results = list(results)

        # If we have results, format them into a DataFrame
        if all_results:
            result_data = [{
                "title": r.title,
                "authors": [str(a) for a in r.authors],
                "summary": r.summary,
                "published": r.published.strftime('%Y-%m-%d'),
                "url": r.entry_id
            } for r in all_results]

            df = pd.DataFrame(result_data)
            df_string = df.to_markdown(index=False)

            # Save the results as a file
            file_name = self.filename if self.filename else f"{(uuid.uuid4())}.parquet"
            file_path = f"{self.workspace}/{file_name}"
            df.to_parquet(file_path, index=False)

            response = {
			"response": post_retrieval_processing_arxiv(llm_json, query, df_string),
            }
        else:
            response = {
                'response': "No results found for the query."
            }

        return json.dumps(response, indent=4)

# Example instantiation
arxiv_query_tool = ArxivQueryTool()
