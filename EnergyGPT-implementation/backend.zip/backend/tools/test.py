# # from openai import OpenAI
# # Perplexity_API_KEY = "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"

# # messages = [
# #     {
# #         "role": "system",
# #         "content": (
# #             ""
# #         ),
# #     },
# #     {
# #         "role": "user",
# #         "content": (
# #             "访问https://tool.chinaz.com/tools/unicode.aspx，并总结一下这个网站的内容"
# #         ),
# #     },
# # ]

# # client = OpenAI(api_key=Perplexity_API_KEY, base_url="https://api.perplexity.ai")

# # # chat completion without streaming
# # # response = client.chat.completions.create(
# # #     model="llama-3.1-sonar-small-128k-online",
# # #     messages=messages,
# # # )
# # # print(response)

# # #chat completion with streaming
# # response_stream = client.chat.completions.create(
# #     model="llama-3.1-sonar-small-128k-online",
# #     messages=messages,
# #     stream=True,
# # )
# # for response in response_stream:
# #     print(response)


# import requests

# url = "https://api.perplexity.ai/chat/completions"

# payload = {
#     "model": "llama-3.1-sonar-small-128k-online",
#     "messages": [
#         {
#             "role": "user",
#             "content": "访问https://tool.chinaz.com/tools/unicode.aspx，并总结一下这个网站的内容"
#         }
#     ]
# }
# headers = {
#     "Authorization": "Bearer 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",
#     "Content-Type": "application/json"
# }

# response = requests.request("POST", url, json=payload, headers=headers)

# print(response.text)


import requests
from bs4 import BeautifulSoup

def scrape_website_content(url):
    try:
        # 发送GET请求获取网页内容
        response = requests.get(url)
        response.raise_for_status()  # 检查请求是否成功

        # 使用BeautifulSoup解析HTML
        soup = BeautifulSoup(response.text, 'html.parser')

        # 获取所有的<p>标签内容
        paragraphs = soup.find_all('p')
        content = [p.get_text() for p in paragraphs]

        return content

    except requests.exceptions.RequestException as e:
        print(f"Error fetching the URL: {e}")
        return None

# 示例用法
url = 'https://www.mccormick.northwestern.edu/research-faculty/directory/profiles/liu-han.html'
content = scrape_website_content(url)
if content:
    for i, paragraph in enumerate(content):
        print(f"Paragraph {i+1}: {paragraph}")
