from langchain.tools import BaseTool

import re, os, json

import matplotlib.pyplot as plt


from pydantic import BaseModel, Field
from typing import Any, Dict, Optional, Sequence, Type, Union
from langchain_core.tools import InjectedToolArg
from typing_extensions import Annotated

from func.r import execute_r_code
from func.python import execute_python_code, get_images
from func.image import upload_image



class RShellInput(BaseModel):
	query: str = Field(..., description="R code snippet to run")
class RShellTool(BaseTool):
	name: str = "r"
	description: str = """
	Execute R code in a persistent R environment. 
	Input: The R code to execute.
	Output: Standard output and error messages.
	Note: Don't save output images to disk. Output images will be rendered automatically.
	"""
	response_format: str = "content_and_artifact"
	args_schema: Type[BaseModel] = RShellInput

	session_id: str = "test"
	envir_dict: dict = {}

	def _run(self, query: str) -> str:
		if self.session_id not in self.envir_dict:
			self.envir_dict[self.session_id] = ro.r("new.env()")
		
		response = execute_r_code(query, self.envir_dict[self.session_id])
		return response, response


class PythonShellInput(BaseModel):
	query: str = Field(..., description="Python code snippet to run")

class PythonShellTool(BaseTool):
	name: str = "python"
	description: str = """
	Execute Python code in a persistent Jupyter environment. 
	Input: The Python code to execute.
	Output: Standard output and error messages.
	Note: Don't save output images to disk. Output images will be rendered automatically.
	"""
	response_format: str = "content_and_artifact"
	args_schema: Type[BaseModel] = PythonShellInput

	globals: dict = {}
	locals: dict = {}
	workspace: str = "data/output"

	session_id: str = "test"

	def _run(self, query: str) -> str:
		if self.session_id not in self.globals:
			self.globals[self.session_id] = {}
			self.locals[self.session_id] = {}
		
		response = execute_python_code(
			query, 
			global_dict=self.globals[self.session_id], 
			local_dict=self.locals[self.session_id]
		)

		return response, response

python_shell_tool = PythonShellTool()

import rpy2.robjects as ro
r_shell_tool = RShellTool()