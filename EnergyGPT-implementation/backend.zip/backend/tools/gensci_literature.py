# flake8: noqa
import pandas as pd, numpy as np, os, re
pd.set_option('display.float_format', lambda x: '%.2f' % x)

import uuid, json, base64
from tools.display_dataframe import display_dataframe
from functools import lru_cache
from langchain.tools import BaseTool
from typing import Any, Dict, Optional, Sequence, Type, Union
from langchain_community.utilities import SQLDatabase
from pydantic import BaseModel, Field, ConfigDict
from langchain_core.tools import BaseTool

from langchain_core.tools import InjectedToolArg
from typing_extensions import Annotated

from func_timeout import func_timeout


def read_sql(query: str, db: SQLDatabase, chunksize: int=1000, timeout: int=120):
	df_list = func_timeout(timeout, pd.read_sql, kwargs={"sql":query, "con":db._engine.connect(), "chunksize":chunksize})
	df = df_list if isinstance(df_list, pd.DataFrame) else pd.concat([i for i in df_list])
	for col in df.columns:
		if df[col].dtype == list:
			df[col] = df[col].apply(lambda x: np.array(x))
	return df


from langchain.prompts import ChatPromptTemplate
post_retrieval = ChatPromptTemplate([
    ("system", """
You are an AI assistant analyzing data from search results. Your task is to answer questions based on the provided SQL query results.
Context:
Question: {question}
SQL Query: {query}
Search Results: {search_results}
Instructions:

Analyze the search results from the SQL query
Answer the question using only information present in the results
Support claims with specific data points from the results
Provide clear, quantitative evidence where applicable
Note any data limitations or gaps relevant to the question

Please provide your analysis of the results and answer the question.
"""),
    ("human", """Answer the following question based on the search results:

Question: {question}
Search Results:
{search_results}


""")
])

from langchain_google_vertexai.model_garden import ChatAnthropicVertex
summary_model = ChatAnthropicVertex(
    model_name="claude-3-5-haiku@20241022", 
    project="ksm-rch-sciscigpt", 
    location="us-east5", 
    temperature=0.5, max_output_tokens=8192
)


class BaseSQLDatabaseTool(BaseModel):
	db_dict: Dict[str, SQLDatabase] = Field(exclude=True)
	model_config = ConfigDict(
		arbitrary_types_allowed=True,
	)

class GenSciLiteratureRetrievalInput(BaseModel):
	query: str = Field(..., description="A valid SQL query compatible with Google BigQuery dialect.")
	question: str = Field(..., description="A question about the literature.")
	

class GenSciLiteratureRetrievalTool(BaseSQLDatabaseTool, BaseTool):
	name: str = "SQL_literature_retrieval"
	description: str = """
	Function: Run a SQL query against BigQuery database. Then answer your question based on the query results.
	This tool could extract the BigQuery database and summarize the results based on your questions.
	It could be used to answer questions about the literature of general science.
	Input:
	- query: A valid SQL query compatible with Google BigQuery dialect, which should retrieve the textual content of the query results.
	- question: A question about the query results.
	Output: The answer to the question based on the literature.
	"""
	response_format: str = "content_and_artifact"
	args_schema: Type[BaseModel] = GenSciLiteratureRetrievalInput

	db_name: str = "SciSciNet_US_V5"
	chunksize: int = 1000
	timeout: int = 240

	def _run(self, query: str, question: str):
		try:
			response = {}

			db = self.db_dict[self.db_name]
			df = read_sql(query, db, self.chunksize, self.timeout)
			
			df_string = display_dataframe(
				df, mode="markdown",
				display_rows=200, 
				decimal_precision=4
			)
			
			response["response"] = summary_model.invoke(post_retrieval.invoke({
				"question": question, "query": query, "search_results": df_string
			})).content

		except Exception as e:
			e_str = re.sub(r'\[SQL:\s*.*?\]', '', str(e), flags=re.DOTALL)
			response['response'] = "{}: {}".format(type(e).__name__, e_str)
		return response, response