from typing import Any, List, Union, Annotated, Literal, TypedDict, Dict, Any, Optional
from langchain_core.messages import AnyMessage, HumanMessage, ToolMessage, AIMessage
# from langgraph.graph import END, START, StateGraph, add_messages
# from langchain_openai import ChatOpenAI
# from langchain_anthropic import ChatAnthropic
# from langchain.prompts import ChatPromptTemplate
from pydantic import BaseModel, Field
import json, os, re
from dotenv import load_dotenv
load_dotenv()
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles  # ADD THIS IMPORT
from langserve import add_routes
app = FastAPI(
	title="LangChain Server",
	version="1.0",
	description="Spin up a simple api server using LangChain's Runnable interfaces",
)

# ADD THIS LINE TO SERVE STATIC FILES
app.mount("/images", StaticFiles(directory="/mnt/data"), name="images")

from langchain_openai import ChatOpenAI
# Set your OpenAI API key
if "OPENAI_API_KEY" not in os.environ:
    os.environ["OPENAI_API_KEY"] = "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"
# Replace your llm initialization with this:
llm = ChatOpenAI(
    model="gpt-4o",  # or "gpt-4o-mini" for cheaper option
    temperature=0,
    max_tokens=8192,
    timeout=None,
    max_retries=2,
)
from agents.sciscigpt import AgentState, all_tools, tools_by_name, define_sciscigpt_graph
for name, tool in tools_by_name.items():
    add_routes(app, tool, path=f"/tools/{name}")
# from langchain.globals import set_debug
sciscigpt_graph = define_sciscigpt_graph(llm)
sciscigpt = sciscigpt_graph.compile(debug=False)
from langchain_core.runnables.config import RunnableConfig
config = RunnableConfig(recursion_limit=500, run_name="SciSciGPT")
class Input(BaseModel):
	messages_str: Optional[str]
	messages: Optional[List[AnyMessage]]
	injected_tool_args: Dict[str, Any] = Field(..., extra={"widget": {"type": "json"}})
class Output(BaseModel):
	output: Any
from langchain_core.runnables import RunnableLambda
from func.messages import convert_to_langchain_messages
def data_to_state(agent_state, injected_tool_args={}, if_multimodal=None, if_inner_reasoning=None):
	messages_str = agent_state["messages_str"]
	agent_state["messages"] = convert_to_langchain_messages(messages_str)
	agent_state["injected_tool_args"] = injected_tool_args
	if if_multimodal is None:
		agent_state["if_multimodal"] = os.getenv("IF_MULTIMODAL", "False").lower() == "true"
	if if_inner_reasoning is None:
		agent_state["if_inner_reasoning"] = os.getenv("IF_INNER_REASONING", "True").lower() == "true"
	return agent_state
add_routes(
	app,
	RunnableLambda(data_to_state) | sciscigpt.with_types(input_type=Input).with_config(config),
	path="/sciscigpt",
)
if __name__ == "__main__":  # FIXED SYNTAX ERROR (was ** instead of __)
	import uvicorn
	uvicorn.run(app, host="0.0.0.0", port=8080)