from langserve import RemoteRunnable
app = RemoteRunnable("http://localhost:8080/sciscigpt")

messages = [HumanMessage("Create a random figure using matplotlib")]
event_list = []
async for chunk in app.astream_events({"messages_str": json.dumps([m.to_json() for m in messages])}):
    event_list.append(chunk)