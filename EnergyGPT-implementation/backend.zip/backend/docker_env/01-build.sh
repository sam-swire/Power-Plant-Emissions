#!/bin/bash

# Set the tag for the Docker image
tag="sciscigpt-env:v1.8"

# Build the Docker image
docker build -t "$tag" .

# Check if the build was successful
if [ $? -eq 0 ]; then
    echo "Docker image built successfully"

    # Tag and push the versioned image
    # Login to Docker Hub first
    docker login
    
    # Tag and push the versioned image
    docker tag "$tag" "erzhuoshao/$tag"
    docker push "erzhuoshao/$tag"

    # Tag and push the latest image
    docker tag "$tag" "liningmao/energygpt-env:latest" 
    docker push "liningmao/energygpt-env:latest"

    echo "Docker images tagged and pushed successfully"
else
    echo "Docker build failed"
    exit 1
fi