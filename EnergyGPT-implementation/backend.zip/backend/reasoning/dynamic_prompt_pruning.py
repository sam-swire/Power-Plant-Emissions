from langchain_core.messages import AnyMessage, ToolMessage, AIMessage, HumanMessage
import json

def extract_tool_evaluation(tool_message: ToolMessage):
	content = tool_message.content
	if isinstance(content, list):
		content_dict = {}
		for text in content:
			try:
				temp = json.loads(text["text"])
				content_dict.update(temp)
			except:
				pass
		tool_evaluation = content_dict.get("tool_evaluation", {}).get("evaluation", "success")
	else:
		content_dict = json.loads(content)
		tool_evaluation = content_dict.get("tool_evaluation", {}).get("evaluation", "success")
	return tool_evaluation

def dynamic_prompt_pruning(messages: list[AnyMessage]):
	# Find the last successful ToolMessage
	tool_evaluation_list = []
	for msg in messages:
		if isinstance(msg, ToolMessage):
			tool_evaluation = extract_tool_evaluation(msg)
			tool_evaluation_list.append((msg.tool_call_id, tool_evaluation))
	success_tool_call_ids = [id for id, eval in tool_evaluation_list if eval == "success"]

	if len(success_tool_call_ids) > 0:
		remove_tool_call_ids = []
		for id, eval in tool_evaluation_list:
			if id == success_tool_call_ids[-1]:
				break
			if eval != "success":
				remove_tool_call_ids.append(id) # All tool calls need to deleted.
	else:
		remove_tool_call_ids = [id for id, eval in tool_evaluation_list]
	
	# Only process if we found a successful ToolMessage
	filtered_messages = []
	for msg in messages:
		if isinstance(msg, ToolMessage):
			if msg.tool_call_id not in remove_tool_call_ids:
				filtered_messages.append(msg)
		elif isinstance(msg, AIMessage):
			# if the AI message contains tool calls need to be removed, skip this message.
			if all(tool_call["id"] not in remove_tool_call_ids for tool_call in msg.tool_calls):
				filtered_messages.append(msg)
		else:
			filtered_messages.append(msg)

	return filtered_messages