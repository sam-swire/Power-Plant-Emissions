from langchain.hub import pull
from langchain_core.messages import AnyMessage, HumanMessage
from langchain_core.language_models import BaseLanguageModel
import os

def simplified_reasoning(model: BaseLanguageModel, messages: list[AnyMessage]):
	system_prompt = pull(os.getenv("SYSTEM_PROMPT")).invoke(input={}).messages

	index = 0
	for i in range(len(messages)):
		if isinstance(messages[i], HumanMessage):
			index = i

	used_messages = system_prompt + messages[index:]
	print("Invoking model with: ", [type(m) for m in used_messages])
	return model.invoke(used_messages)
