


from langchain.hub import pull
from langchain_core.messages import AnyMessage
from langchain_core.language_models import BaseLanguageModel
from langchain_core.messages import AnyMessage, HumanMessage, ToolMessage, AIMessage
import re
import json
from func.messages import xml_extract

def check_tool_args(tool, tool_args):
	# Get the expected args from the tool's schema
	expected_args = tool.args_schema.__fields__ if hasattr(tool, 'args_schema') else {}
	tool_args_dict = json.loads(tool_args) if isinstance(tool_args, str) else tool_args
	
	# Check for missing required args
	missing_args = []
	for arg_name, field in expected_args.items():
		if field.is_required() and arg_name not in tool_args_dict:
			missing_args.append(arg_name)
	return missing_args


def tool_evaluate(state, tool_message, model):
	human_messages = pull("liningmao/energygpt-tool-eval").invoke({}).messages
	
	output = model.invoke([
		*state["messages"], 
		tool_message, 
		*human_messages
	]).content

	output = output[0]["text"] if not isinstance(output, str) else output
	response = { tag: xml_extract(output, tag) for tag in ["evaluation", "reflection", "reward"] }
	response_str = "\n".join(["<" + key + ">" + response[key] + "</" + key + ">" for key in ["reflection", "reward"] if response[key]])
	return response_str