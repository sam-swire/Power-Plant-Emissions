from langchain.hub import pull
from langchain_core.messages import AnyMessage
from langchain_core.language_models import BaseLanguageModel
import os

def vanilla_reasoning(model: BaseLanguageModel, messages: list[AnyMessage]):
	system_prompt = pull(os.getenv("SYSTEM_PROMPT")).invoke(input={}).messages
	return model.invoke(system_prompt + messages)




from langchain_core.messages import AIMessage
from reasoning.tool_invocation import check_tool_args
def vanilla_reasoning_with_tool_calls(model: BaseLanguageModel, openai_model: BaseLanguageModel, messages: list[AnyMessage], tools_by_name):
	try:
		system_prompt = pull(os.getenv("SYSTEM_PROMPT")).invoke(input={}).messages
		print("Trying to invoke anthropic model...")
		for i in range(1):
			if_tool_call_success = True

			response = model.invoke(system_prompt + messages)

			for tool_call in response.tool_calls:
				tool_name, tool_id, tool_args = tool_call["name"], tool_call["id"], tool_call["args"]

				tool = tools_by_name[tool_name]
				missing_args = check_tool_args(tool, tool_args)
				print(f"Tool name: {tool_name}, tool id: {tool_id}, tool args: {tool_args}")
				print(f"Missing args: {missing_args}")

				if len(missing_args) > 0:
					if_tool_call_success = False
					print(f"Tool call fail for the {i}th time...")

			if if_tool_call_success:
				return response
		print(f"Transfer to openai model...")
		response = openai_model.invoke(system_prompt + messages)
		print(f"Done with openai model...")
		return response
	except Exception as e:
		return AIMessage(content="{}: {}".format(type(e).__name__, str(e)))
	
