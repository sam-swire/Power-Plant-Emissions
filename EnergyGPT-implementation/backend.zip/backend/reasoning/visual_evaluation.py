from langchain.hub import pull
from langchain_core.language_models import BaseLanguageModel
from langchain_core.messages import AnyMessage, SystemMessage, HumanMessage, AIMessage, ToolMessage
import re, json, os
from func.image import show_images_to_llm
from func.messages import xml_extract

from langchain_google_vertexai.model_garden import ChatAnthropicVertex
visual_evaluator = ChatAnthropicVertex(
    model_name="claude-3-5-sonnet-v2@20241022",  
    project="ksm-rch-sciscigpt", 
    location="us-east5", 
    temperature=0.5, max_output_tokens=8192
)


def visual_evaluate(state, response, tool_call_id, model=visual_evaluator):
	system_prompt = pull("liningmao/energygpt-visual-eval").invoke({}).messages
	tool_message = ToolMessage(content=response, tool_call_id=tool_call_id)

	human_messages = [msg for msg in state["messages"] if isinstance(msg, HumanMessage)]
	
	output = model.invoke(
		[*human_messages, state["messages"][-1], tool_message, HumanMessage(content=show_images_to_llm(response)), *system_prompt]
	).content


	output = output[0]["text"] if not isinstance(output, str) else output
	response = { tag: xml_extract(output, tag) for tag in ["reflection", "caption", "evaluation", "reward"] }
	response_str = "\n".join(["<" + key + ">" + response[key] + "</" + key + ">" for key in ["caption", "reflection", "reward"] if response[key]])
	return response_str