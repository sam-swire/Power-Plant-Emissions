# SciSciGPT Backend

The backend for SciSciGPT, an AI agent system for scientific research assistance in the field of science of science (SciSci).

## Overview

SciSciGPT's backend is built on LangChain with custom agents and tools designed for scientific literature analysis, data processing, and research assistance.

## Features

- Scientific literature search and analysis
- Data visualization capabilities
- Jupyter notebook integration
- Neo4j graph database connectivity
- Google Cloud Platform integration

## Setup

1. Copy `env_example` to `.env` and fill in your API keys.
2. Install dependencies
3. Run with `python app.py` or use Docker with `docker-compose up`

## Tools

SciSciGPT includes specialized tools for:
- Scientific literature analysis
- Data visualization
- SQL querying