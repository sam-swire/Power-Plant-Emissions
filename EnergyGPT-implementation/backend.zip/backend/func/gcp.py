from google.cloud import storage
import os

def upload_file_to_gcp(local_path: str, gcp_path=None, bucket_name: str="sciscigpt-fs"):
    if gcp_path is None:
        gcp_path = os.path.basename(local_path)

    client = storage.Client()
    bucket = client.bucket(bucket_name)
    
    blob = bucket.blob(gcp_path)
    blob.upload_from_filename(local_path)
    # print(f"Uploaded {local_path} to {gcp_path}")
    return blob.public_url