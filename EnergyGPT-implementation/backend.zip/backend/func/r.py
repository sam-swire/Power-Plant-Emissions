import rpy2.robjects as ro
from rpy2.robjects.packages import importr, InstalledSTPackage
from rpy2.rinterface_lib.embedded import RRuntimeError
from typing import Any, Dict, Optional, Sequence, Type, Union
import json, os, uuid
from func.image import upload_image


def execute_r_code(
        query: str,
        envir: Optional[ro.Environment]=ro.r("new.env()"),
        grdevices: Optional[InstalledSTPackage]=importr("grDevices"),
        workspace: str="/tmp/fig"
    ):

    os.makedirs(workspace, exist_ok=True)

    response = {}

    ro.r.options(warn=-1)
    ro.r('txtcon <- textConnection("out", "w", local=TRUE); sink(txtcon); sink(txtcon, type="message")')

    figure_output = []
    try:
        status = 200
        for expr in ro.r(f"parse(text={json.dumps(query)})"):
            output_figure = os.path.join(workspace, f"data/output/{uuid.uuid4()}.png")

            grdevices.png(file=output_figure, width=1024, height=1024)
            ro.r.eval(expr, envir=envir)
            grdevices.dev_off()

            if os.path.exists(output_figure):
                figure_output.append(output_figure)
    except (Exception, RRuntimeError) as e:
        # print(e)    
        status = 500
    ro.r('sink(); sink(type="message"); close(txtcon); rm(txtcon);')

    response['response'] = '\n'.join(list(ro.r('out')))
    
    print(figure_output)
    if len(figure_output) > 0:
        response["images"] = []
        for i in figure_output:
            response["images"].append(
                {
                    "name": os.path.basename(i),
                    "id": os.path.basename(i),
                    "mime_type": "image/png",
                    "download_link": upload_image(i)
                }
            )
            os.remove(i)

    return response


if __name__ == "__main__":
    query = """
    plot(1:10)
    plot(1:10)
    plot(1:10)

    # Intentionally introducing an error in R code
    print("This line will execute normally")
    nonexistent_function()  # This function doesn't exist, so it will cause an error
    print("This line won't be reached due to the error above")
    """
    print(execute_r_code(query))
