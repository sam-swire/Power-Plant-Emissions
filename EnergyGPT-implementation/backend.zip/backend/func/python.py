import ast, re, os, traceback
from contextlib import redirect_stdout, redirect_stderr
from io import StringIO, BytesIO
import matplotlib.pyplot as plt
from func.image import upload_image
from PIL import Image
import uuid


def get_images():
	images = []
	for i in plt.get_fignums():
		fig = plt.figure(i)

		buffer = BytesIO()
		fig.savefig(buffer, format="png")
		buffer.seek(0)

		image = Image.open(buffer)
		image_path = f"data/output/{uuid.uuid4()}.png"
		image.save(image_path)

		buffer.close()
		plt.close(fig)

		images.append(image_path)
	return images


def sanitize(query: str) -> str:
	# This code is used to sanitize the input query:
	# 1. It removes any leading whitespace, backticks, and optional "python" prefix (case-insensitive)
	# 2. It removes any trailing whitespace or backticks
	query = re.sub(r"^(\s|`)*(?i:python)?\s*", "", query)
	query = re.sub(r"(\s|`)*$", "", query)
	return query


def execute_python_code(query, global_dict={}, local_dict={}, id: int = 1):
	plt.ioff()

	response = {}
	output_list = []

	try:
		query = sanitize(query)
		tree = ast.parse(query)
		
		# Execute all but the last line
		unparsed_code = ast.unparse(ast.Module(tree.body, type_ignores=[]))

		if len(tree.body) > 1:
			exec_code = ast.unparse(ast.Module(tree.body[:-1], type_ignores=[]))
			io_buffer = StringIO()
			with redirect_stdout(io_buffer), redirect_stderr(io_buffer):
				exec(exec_code, global_dict)
				output_list.append(io_buffer.getvalue())

		# Execute or evaluate the last line
		last_line = ast.unparse(ast.Module(tree.body[-1:], type_ignores=[]))
		io_buffer = StringIO()
		with redirect_stdout(io_buffer), redirect_stderr(io_buffer):
			if isinstance(tree.body[-1], ast.Expr):
				ret = eval(last_line, global_dict)
				output_list.append(str(ret) if ret is not None else io_buffer.getvalue())
			else:
				exec(last_line, global_dict)
				output_list.append(io_buffer.getvalue())
		status = 200
		
	except Exception as e:
		error_type = type(e).__name__
		error_message = str(e)
		
		# Get the line number from the traceback
		tb = traceback.extract_tb(e.__traceback__)
		error_line = tb[-1].lineno if tb else 1
		
		# Split the query into lines
		query_lines = unparsed_code.split('\n')
		total_lines = len(query_lines)
		
		# Determine the range of lines to show (2 before and 2 after if possible)
		start_line = max(1, error_line - 2)
		end_line = min(total_lines, error_line + 2)
		
		# Prepare the context lines
		context_lines = []
		for i in range(start_line, end_line + 1):
			prefix = '--->' if i == error_line else '    '
			context_lines.append(f"{prefix} {i} {query_lines[i-1].strip()}")
		
		error_output = (
			f"----------------------------------------------------------------\n"
			f"{error_type:<30} Traceback (most recent call last)\n"
			f"Cell In[{id}], line {error_line}\n"
			f"{chr(10).join(context_lines)}\n\n"
			f"{error_type}: {error_message}\n"
		)
		
		output_list.append(error_output)
		status = 500

	output_str = "".join(output_list)
	output_img = get_images()

	response["response"] = sanitize(output_str)
	if len(output_img) > 0:
		response["images"] = [
			{
				"name": os.path.basename(i),
				"id": os.path.basename(i),
				"mime_type": "image/png",
				"download_link": upload_image(i)
			} for i in output_img
		]
	
	return response