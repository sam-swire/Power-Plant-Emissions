import uuid, re

def convert_to_langchain_messages(data):
	from langchain_core.messages import HumanMessage, AIMessage, ToolMessage
	import json

	messages_data = json.loads(data)
	messages = []

	for msg in messages_data:
		if msg['id'][-1] == 'HumanMessage':
			messages.append(HumanMessage(**msg['kwargs']))
		elif msg['id'][-1] == 'AIMessage':
			messages.append(AIMessage(**msg['kwargs']))
		elif msg['id'][-1] == 'ToolMessage':
			messages.append(ToolMessage(**msg['kwargs']))
	return messages


import json
from langchain_core.messages import HumanMessage, AIMessage, ToolMessage

def display_message(message):
	# ANSI color codes
	BLUE = '\033[94m'
	GREEN = '\033[92m'
	YELLOW = '\033[93m'
	RED = '\033[91m'
	PURPLE = '\033[95m'
	BOLD = '\033[1m'
	ENDC = '\033[0m'
	
	if isinstance(message, AIMessage):
		content = message.content
		print(f"{BLUE}{BOLD}AI Message:{ENDC}")
		if type(content) == str:
			print(f"{BLUE}{content}{ENDC}")
		else:
			for i in content:
				if i["type"] == "text":
					print(f"{BLUE}{i['text']}{ENDC}")

		if message.tool_calls:
			print(f"\n{YELLOW}{BOLD}Tool Calls:{ENDC}")
			print(f"{YELLOW}{BOLD}name:{ENDC} {YELLOW}{message.tool_calls[0]['name']}{ENDC}")
			print(f"{YELLOW}{BOLD}args:{ENDC} {YELLOW}{message.tool_calls[0]['args']}{ENDC}")
		print("\n")

	elif isinstance(message, ToolMessage):
		content = message.content
		if not isinstance(content, str):
			content = content[0]['text']
		else:
			content = content

		print(f"{PURPLE}{BOLD}Tool Response:{ENDC}")
		print(f"{PURPLE}{eval(content)['response']}{ENDC}")
		print("\n")
		
	elif isinstance(message, HumanMessage):
		content = message.content
		print(f"{GREEN}{BOLD}Human Message:{ENDC}")
		print(f"{GREEN}{content}{ENDC}")
		print("\n")




from langchain_core.messages import HumanMessage, AIMessage, ToolMessage, SystemMessage, AnyMessage
import json
from copy import deepcopy
def reformat_messages(messages: list[AnyMessage]):
	# If the last message is an AIMessage, reformat the messages
	# by adding the content of the last message to the second last message (ToolMessage)
	messages = deepcopy(messages)
	if isinstance(messages[-1], AIMessage):
		message_0_content = messages[-1].content
		message_0_content = [{"type": "text", "text": message_0_content}] if isinstance(message_0_content, str) else message_0_content
		message_1_content = messages[-2].content
		message_1_content = [{"type": "text", "text": message_1_content}] if isinstance(message_1_content, str) else message_1_content
		content = message_1_content + message_0_content
		content = [{"type": "text", "text": i['text']} for i in content]
		
		temp_message = deepcopy(messages[-2])
		temp_message.content = content
		messages[-2] = temp_message
		return messages[:-1]
	else:
		return messages
	

def system_to_human(messages: list[AnyMessage]):
	# If the message is a SystemMessage, convert it to a HumanMessage
	human_messages = []
	for message in messages:
		if isinstance(message, SystemMessage):
			human_messages.append(HumanMessage(content=message.content))
		else:
			human_messages.append(message)
	return human_messages


def xml_extract(response: str, tag: str):
	# Extract the text between the tags
	# If the tag is not found, return an empty string
	match = re.search(fr'<{tag}>(.*?)</{tag}>', response, re.DOTALL)
	if match:
		return match.group(1).strip() if match.group(1) else ""
	else:
		return ""
	

from langchain_core.messages import HumanMessage, AIMessage, AnyMessage
from copy import deepcopy
import re
def remove_inner_monologue(messages: list[AnyMessage], monologue_tags: list[str]):
	messages = deepcopy(messages)
	# Remove the text between the tags
	for tag in monologue_tags:
		pattern = re.compile(fr'<{tag}>(.*?)</{tag}>', re.DOTALL)
		for message in messages:
			if isinstance(message, AIMessage):
				if isinstance(message.content, str):
					message.content = pattern.sub("", message.content).strip()
				else:
					for item in message.content:
						if item["type"] == "text":
							item["text"] = pattern.sub("", item["text"]).strip()
	return messages