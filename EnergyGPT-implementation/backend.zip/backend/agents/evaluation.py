from langchain_core.messages import HumanMessage, AIMessage, ToolMessage
from agents.nodes import AgentState
from langchain.hub import pull
from func.messages import xml_extract, remove_inner_monologue
import json
from func.image import if_message_contains_image


def evaluate(llm, toolsets_by_specialist, state: AgentState):
	newest_task = state["task_list"][-1]
	specialist, task, task_loc = newest_task["specialist"], newest_task["task"], newest_task["loc"]
	tools = toolsets_by_specialist[specialist]
	model = llm.bind_tools(tools)
	
	if newest_task["status"] == "completed":
		content = task_evaluation(model, state)
		newest_task["status"] = "evaluated"
	else:
		if if_message_contains_image(state["messages"][-1]):
			content = visual_evaluation(model, state)
		else:
			content = tool_evaluation(model, state)
	
	return { "messages": [AIMessage(content=content)], "task_list": state["task_list"] }


def task_evaluation(model, state: AgentState):
	# print("task_evaluation")
	newest_task = state["task_list"][-1]
	specialist, task, task_loc = newest_task["specialist"], newest_task["task"], newest_task["loc"]
	
	task_message = HumanMessage(content=task)
	messages = state["messages"][task_loc:]
	
	# Fix message sequence to ensure proper tool call/response pairing
	fixed_messages = ensure_proper_tool_response_sequence(messages)
	cleaned_messages = remove_inner_monologue(fixed_messages, ["thinking"])
	
	evaluation_messages = pull("liningmao/energygpt-task-eval").invoke({"task": task}).messages
	
	try:
		response = model.invoke([
			task_message,
			*cleaned_messages,
			*evaluation_messages
		]).content
		return str(response)
	except Exception as e:
		print(f"Task evaluation error: {e}")
		return f"Task evaluation completed with issues: {str(e)}"


from func.image import show_images_to_llm

def visual_evaluation(model, state: AgentState):
	# print("visual_evaluation")
	newest_task = state["task_list"][-1]
	specialist, task, task_loc = newest_task["specialist"], newest_task["task"], newest_task["loc"]
	messages = state["messages"][task_loc:]
	
	# Fix message sequence before processing
	fixed_messages = ensure_proper_tool_response_sequence(messages)
	
	evaluation_messages = pull("liningmao/energygpt-visual-eval").invoke({"task": task}).messages
	
	def fix_content_types(content):
		"""Ensure all content blocks have required 'type' field"""
		if isinstance(content, str):
			return content
		elif isinstance(content, list):
			fixed_content = []
			for item in content:
				if isinstance(item, dict):
					# Make a copy to avoid modifying original
					fixed_item = item.copy()
					if "type" not in fixed_item:
						if "text" in fixed_item:
							fixed_item["type"] = "text"
						elif "image_url" in fixed_item:
							fixed_item["type"] = "image_url"
						elif "source" in fixed_item:
							fixed_item["type"] = "image"
						else:
							# Default to text if we can't determine
							fixed_item["type"] = "text"
					fixed_content.append(fixed_item)
				elif isinstance(item, str):
					fixed_content.append({"type": "text", "text": item})
				else:
					fixed_content.append(item)
			return fixed_content
		else:
			return content
	
	raw_content = show_images_to_llm(fixed_messages[-1]).content
	fixed_content = fix_content_types(raw_content)
	image_message = HumanMessage(content=fixed_content)
	
	try:
		output = model.invoke([
			HumanMessage(content=task),
			*remove_inner_monologue(fixed_messages, ["thinking"])[-2:], 
			image_message, 
			*evaluation_messages
		]).content
		output = output[0]["text"] if not isinstance(output, str) else output
		response = { tag: xml_extract(output, tag) for tag in ["reflection", "caption", "evaluation", "reward"] }
		response_str = "\n".join(["<" + key + ">" + response[key] + "</" + key + ">" for key in ["caption", "reflection", "reward"] if response[key]])
		return response_str
	except Exception as e:
		print(f"Visual evaluation error: {e}")
		return f"Visual evaluation completed with issues: {str(e)}"


def tool_evaluation(model, state: AgentState):
	# print("tool_evaluation")
	newest_task = state["task_list"][-1]
	specialist, task, task_loc = newest_task["specialist"], newest_task["task"], newest_task["loc"]
	
	# Get messages from task location onwards
	task_messages = state["messages"][task_loc:]
	
	# CRITICAL FIX: Ensure proper tool call/response pairing before sending to model
	fixed_messages = ensure_proper_tool_response_sequence(task_messages)
	cleaned_messages = remove_inner_monologue(fixed_messages, ["thinking"])
	
	evaluation_messages = pull("liningmao/energygpt-tool-eval").invoke({"task": task}).messages
	
	try:
		output = model.invoke([
			HumanMessage(content=task),
			*cleaned_messages,
			*evaluation_messages
		]).content
		output = output[0]["text"] if not isinstance(output, str) else output
		response = { tag: xml_extract(output, tag) for tag in ["reflection", "reward", "thinking"] }
		response_str = "\n".join(["<" + key + ">" + response[key] + "</" + key + ">" for key in ["reflection", "reward", "thinking"] if response[key]])
		return response_str
	except Exception as e:
		print(f"Tool evaluation error: {e}")
		return f"Tool evaluation completed with issues: {str(e)}"


def ensure_proper_tool_response_sequence(messages):
	"""
	CRITICAL FIX: Ensure all AIMessages with tool_calls have corresponding ToolMessage responses
	This prevents the OpenAI API error: "assistant message with 'tool_calls' must be followed by tool messages"
	UPDATED: Handle both dictionary and object formats for tool_calls
	"""
	if not messages:
		return messages
	
	fixed_messages = []
	pending_tool_calls = {}  # track tool_call_id -> tool_call mapping
	
	for i, msg in enumerate(messages):
		fixed_messages.append(msg)
		
		# Track tool calls that need responses
		if isinstance(msg, AIMessage) and hasattr(msg, 'tool_calls') and msg.tool_calls:
			for tool_call in msg.tool_calls:
				# Handle both dictionary and object formats
				if isinstance(tool_call, dict):
					call_id = tool_call.get('id')
					if call_id:
						pending_tool_calls[call_id] = tool_call
				else:
					# Object format (has .id attribute)
					if hasattr(tool_call, 'id'):
						pending_tool_calls[tool_call.id] = tool_call
		
		# Remove handled tool calls when we see responses
		elif isinstance(msg, ToolMessage) and msg.tool_call_id in pending_tool_calls:
			del pending_tool_calls[msg.tool_call_id]
	
	# Add dummy responses for any unhandled tool calls
	for call_id, tool_call in pending_tool_calls.items():
		print(f"WARNING: Adding missing tool response for call_id: {call_id}")
		
		# Create appropriate dummy response based on tool type
		# Handle both dictionary and object formats for tool_call
		tool_name = None
		if isinstance(tool_call, dict):
			# Dictionary format
			if 'function' in tool_call and isinstance(tool_call['function'], dict):
				tool_name = tool_call['function'].get('name')
			elif 'function' in tool_call and hasattr(tool_call['function'], 'name'):
				tool_name = tool_call['function'].name
		else:
			# Object format
			if hasattr(tool_call, 'function') and tool_call.function:
				if hasattr(tool_call.function, 'name'):
					tool_name = tool_call.function.name
		
		# Generate appropriate error message
		if tool_name:
			if tool_name in ['df_list_table', 'sql_list_table']:
				dummy_content = "Error: Tool execution was interrupted - no tables listed"
			elif tool_name in ['df_get_schema', 'sql_get_schema']:
				dummy_content = "Error: Tool execution was interrupted - no schema retrieved"
			elif tool_name in ['df_query', 'sql_query']:
				dummy_content = "Error: Tool execution was interrupted - no query results"
			else:
				dummy_content = f"Error: Tool '{tool_name}' execution was interrupted"
		else:
			dummy_content = "Error: Tool execution was interrupted"
		
		dummy_response = ToolMessage(
			content=dummy_content,
			tool_call_id=call_id
		)
		fixed_messages.append(dummy_response)
	
	return fixed_messages


def validate_message_sequence(messages):
	"""
	Additional validation to debug message sequence issues
	"""
	tool_calls_waiting = []
	
	for i, msg in enumerate(messages):
		msg_type = type(msg).__name__
		
		if isinstance(msg, AIMessage) and hasattr(msg, 'tool_calls') and msg.tool_calls:
			# Handle both dictionary and object formats
			tool_call_ids = []
			for tc in msg.tool_calls:
				if isinstance(tc, dict):
					tc_id = tc.get('id')
					if tc_id:
						tool_call_ids.append(tc_id)
				else:
					if hasattr(tc, 'id'):
						tool_call_ids.append(tc.id)
			
			tool_calls_waiting.extend(tool_call_ids)
			print(f"Message {i}: {msg_type} with tool_calls: {tool_call_ids}")
		
		elif isinstance(msg, ToolMessage):
			if msg.tool_call_id in tool_calls_waiting:
				tool_calls_waiting.remove(msg.tool_call_id)
				print(f"Message {i}: {msg_type} responding to: {msg.tool_call_id}")
			else:
				print(f"Message {i}: {msg_type} with unexpected tool_call_id: {msg.tool_call_id}")
		
		else:
			print(f"Message {i}: {msg_type}")
	
	if tool_calls_waiting:
		print(f"VALIDATION ERROR: Unhandled tool calls: {tool_calls_waiting}")
		return False
	
	print("VALIDATION PASSED: All tool calls have responses")
	return True


# Debug function to help troubleshoot message sequences
def debug_message_sequence(state: AgentState, task_loc: int):
	"""Debug helper to print message sequence around tool calls"""
	messages = state["messages"][task_loc:]
	print(f"\n=== DEBUG: Message Sequence (from task_loc {task_loc}) ===")
	
	for i, msg in enumerate(messages):
		msg_type = type(msg).__name__
		
		if isinstance(msg, AIMessage):
			if hasattr(msg, 'tool_calls') and msg.tool_calls:
				tool_names = []
				tool_ids = []
				for tc in msg.tool_calls:
					# Handle both dictionary and object formats
					if isinstance(tc, dict):
						if 'function' in tc and isinstance(tc['function'], dict):
							tool_names.append(tc['function'].get('name', 'unknown'))
						elif 'function' in tc and hasattr(tc['function'], 'name'):
							tool_names.append(tc['function'].name)
						else:
							tool_names.append('unknown')
						
						tc_id = tc.get('id')
						if tc_id:
							tool_ids.append(tc_id)
					else:
						if hasattr(tc, 'function'):
							tool_names.append(tc.function.name if hasattr(tc.function, 'name') else 'unknown')
						else:
							tool_names.append('unknown')
						
						if hasattr(tc, 'id'):
							tool_ids.append(tc.id)
				
				print(f"{i}: {msg_type} with tools: {tool_names} (IDs: {tool_ids})")
			else:
				content_preview = msg.content[:100] if msg.content else "No content"
				print(f"{i}: {msg_type}: {content_preview}...")
		
		elif isinstance(msg, ToolMessage):
			content_preview = msg.content[:100] if msg.content else "No content"
			print(f"{i}: {msg_type} (call_id: {msg.tool_call_id}): {content_preview}...")
		
		elif isinstance(msg, HumanMessage):
			content_preview = msg.content[:100] if msg.content else "No content"
			print(f"{i}: {msg_type}: {content_preview}...")
		
		else:
			print(f"{i}: {msg_type}")
	
	print("=== END DEBUG ===\n")
	
	# Validate the sequence
	return validate_message_sequence(messages)