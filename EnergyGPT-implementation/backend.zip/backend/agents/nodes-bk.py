from langchain.hub import pull
from langchain_core.messages import AnyMessage, HumanMessage, ToolMessage, AIMessage
from typing import Annotated, Dict, Any, TypedDict, Literal
from langgraph.prebuilt import ToolNode
from func.messages import reformat_messages, system_to_human, remove_inner_monologue


class Task(TypedDict):
	task: str
	loc: int
	status: Literal["created", "in_progress", "completed", "evaluated"]
	specialist: Literal["research_manager", "database_specialist", "analytics_specialist", "literature_specialist", "evaluation_specialist"]


from langgraph.graph import add_messages
class AgentState(TypedDict):
	messages: Annotated[list[AnyMessage], add_messages]
	messages_str: str
	injected_tool_args: Dict[str, Any]
	task_list: list[Task]
	end: bool


def call_research_manager(llm, tools, pruning_func, state: AgentState):
	"""ResearchManager node is the first node in the agent.
	It directly interacts with the user.
	A session starts with a ResearchManager node.
	ResearchManager could assign tasks to other agents.
	ResearchManager could end a session."""

	import pickle
	import os
	
	# Save current state to pickle file
	state_file = "pickle/agent_state.pkl"
	with open(state_file, "wb") as f:
		pickle.dump(state, f)

	model = llm.bind_tools(tools)

	system_messages = pull("liningmao/energygpt_research_manager").invoke({}).messages
	human_message = HumanMessage(content="""
	1. If further response is needed, assign a task to one of: database_specialist, analytics_specialist, literature_specialist
	2. If user request has been fully addressed, synthesize a final answer.""")

	new_messages = reformat_messages(reformat_messages(pruning_func([
		*system_messages, 
		*remove_inner_monologue(state['messages'], ["thinking"]), 
		human_message
	])))
	response = model.invoke(new_messages)

	if response.tool_calls:
		specialist = response.tool_calls[0]["name"]
		task = response.tool_calls[0]["args"].get("task", "")
		task_loc = len(state['messages']) + 2 # +2 for the ai message
		# Assign a task to a specialist (literature_specialist, database_specialist, analytics_specialist)
		new_task = { "task": task, "loc": task_loc, "status": "created", "specialist": specialist }
		return { "messages": [response], "end": False, "task_list": state.get("task_list", []) + [new_task] } 
	else:
		# End the session
		return { "messages": [response], "end": True } 


def call_specialist(llm, tools, pruning_func, state: AgentState):
	newest_task = state["task_list"][-1]
	specialist, task, task_loc = newest_task["specialist"], newest_task["task"], newest_task["loc"]
	model = llm.bind_tools(tools)

	system_messages = pull(f"liningmao/energygpt_{specialist}").invoke({"task": task}).messages
	human_message = HumanMessage(content=f"<user>Here is the task you need to perform, follow the guidelines in the system message.<task>{task}</task></user>")

	response = model.invoke(reformat_messages(pruning_func([
		*system_messages,
		# *remove_inner_monologue(state['messages'][:task_loc], ["thinking"]), # Everything before the task
		# *system_to_human(system_messages), 
		human_message,
		*state['messages'][task_loc:] # The workflow of the specialist
	])))

	if response.tool_calls and response.tool_calls[0]["name"] != "evaluation_specialist":
		# Continue the task (reasoning - tool call iteration)
		newest_task["status"] = "in_progress"
		return { "messages": [response], "task_list": state["task_list"] }	
	else:
		# End this task, pass to evaluation_specialist
		newest_task["status"] = "completed"
		if response.content[0]["type"] == "text":	
			response.tool_calls = []
			response.content = response.content[0]["text"] if isinstance(response.content, list) else response.content
			return { "messages": [response], "task_list": state["task_list"] } 
		else:
			return { "task_list": state["task_list"] } 

import json
from reasoning.visual_evaluation import visual_evaluate
from reasoning.tool_evaluation import check_tool_args, tool_evaluate
from langchain_core.messages import ToolMessage

def call_tool(tools_by_name, state: AgentState):

	for tool_call in state["messages"][-1].tool_calls:
		tool_name, tool_id, tool_args = tool_call["name"], tool_call["id"], tool_call["args"]
		tool = tools_by_name[tool_name]
		
		##### Set tool attributes #####
		tool_config = state["injected_tool_args"].get(tool_name, {})
		for key, value in tool_config.items():
			setattr(tool, key, value)

		response = tool.invoke(tool_args)
		response = json.loads(response) if isinstance(response, str) else response

		content = [{"type": "text", "text": json.dumps(response)}]
		
		# Adopt Visual Evaluator if any chart is generated and tool evaluation is success
		# if len(response.get("images", [])) > 0:
		# 	tool_evaluation = visual_evaluate(state, response, tool_id, model=llm)
		# 	content.append({"type": "text", "text": tool_evaluation})
		# else:
		# if True:
		# 	# If no chart is generated, adopt tool evaluator
		# 	tool_message = ToolMessage(content=response, tool_call_id=tool_id)
		# 	tool_evaluation = tool_evaluate(state, tool_message, model=llm)
		# 	content.append({"type": "text", "text": tool_evaluation})

		tool_message = ToolMessage(content=content, tool_call_id=tool_id)
	return { "messages": [tool_message] }



