from langchain_core.messages import HumanMessage, AIMessage
from agents.nodes import AgentState
from langchain.hub import pull
from func.messages import xml_extract, remove_inner_monologue
import json
from func.image import if_message_contains_image

def evaluate(llm, toolsets_by_specialist, state: AgentState):
	newest_task = state["task_list"][-1]
	specialist, task, task_loc = newest_task["specialist"], newest_task["task"], newest_task["loc"]
	tools = toolsets_by_specialist[specialist]
	model = llm.bind_tools(tools)

	if newest_task["status"] == "completed":
		content = task_evaluation(model, state)
		newest_task["status"] = "evaluated"
	else:
		if if_message_contains_image(state["messages"][-1]):
			content = visual_evaluation(model, state)
		else:
			content = tool_evaluation(model, state)
	return { "messages": [AIMessage(content=content)], "task_list": state["task_list"] }


def task_evaluation(model, state: AgentState):
	# print("task_evaluation")
	newest_task = state["task_list"][-1]
	specialist, task, task_loc = newest_task["specialist"], newest_task["task"], newest_task["loc"]
	
	task_message = HumanMessage(content=task)
	messages = state["messages"][task_loc:]
	evaluation_messages = pull("liningmao/energygpt-task-eval").invoke({"task": task}).messages

	response = model.invoke([
		task_message,
		*remove_inner_monologue(messages, ["thinking"]),
		*evaluation_messages
	]).content
	return str(response)


from func.image import show_images_to_llm
def visual_evaluation(model, state: AgentState):
	# print("visual_evaluation")
	newest_task = state["task_list"][-1]
	specialist, task, task_loc = newest_task["specialist"], newest_task["task"], newest_task["loc"]

	messages = state["messages"][task_loc:]
	evaluation_messages = pull("liningmao/energygpt-visual-eval").invoke({"task": task}).messages
	
	image_message = HumanMessage(content=show_images_to_llm(messages[-1]).content)

	output = model.invoke([
		HumanMessage(content=task),
		*remove_inner_monologue(messages, ["thinking"])[-2:], 
		image_message, 
		*evaluation_messages
	]).content

	output = output[0]["text"] if not isinstance(output, str) else output
	response = { tag: xml_extract(output, tag) for tag in ["reflection", "caption", "evaluation", "reward"] }
	response_str = "\n".join(["<" + key + ">" + response[key] + "</" + key + ">" for key in ["caption", "reflection", "reward"] if response[key]])
	return response_str

def tool_evaluation(model, state: AgentState):
	# print("tool_evaluation")
	newest_task = state["task_list"][-1]
	specialist, task, task_loc = newest_task["specialist"], newest_task["task"], newest_task["loc"]

	evaluation_messages = pull("liningmao/energygpt-tool-eval").invoke({"task": task}).messages

	output = model.invoke([
		HumanMessage(content=task),
		*remove_inner_monologue(state["messages"][task_loc:], ["thinking"]), 
		*evaluation_messages
	]).content

	output = output[0]["text"] if not isinstance(output, str) else output
	response = { tag: xml_extract(output, tag) for tag in ["reflection", "reward", "thinking"] }
	response_str = "\n".join(["<" + key + ">" + response[key] + "</" + key + ">" for key in ["reflection", "reward", "thinking"] if response[key]])
	return response_str



