from langchain.prompts import ChatPromptTemplate
from langchain_core.messages import HumanMessage, SystemMessage


HyDE_pre_retrieval = ChatPromptTemplate([
    ("system", """You are an AI assistant specializing in science of science literature. Your task is to generate hypothetical, relevant paragraphs that might appear in {section_type} section in scientific papers."""),
    ("human", """Create 3 hypothetical paragraphs of the given that could appear in {section_type} section in papers related to the given query:
Query: {query}

Instructions:
1. Generate paragraph that are concise yet informative, reflecting current science of science writing styles.
2. You must ensure that the generated paragraphs are likely to fit into the given section.

Your output must follow this JSON format. You are strictly banned to generate anything beyond this JSON format.
{{
    "Section 1": "Detailed content for Section 1...",
    "Section 2": "Detailed content for Section 2...",
    "Section 3": "Detailed content for Section 3..."
}}""")
])


HyDE_post_retrieval = ChatPromptTemplate([
    ("system", """1. Create a detailed literature review that directly answers the user's query.
2. Synthesize the information into detailed, informative, and coherent paragraphs.
3. Highlight key findings and their relevance to answering the query.
4. Use in-text citations `[id]` to link claims to specific papers.
5. Ensure the summary provides a clear and direct answer to the original query.
6. Provide a list of references used in the summary.

Provide the summary in this JSON format. You are strictly banned to generate anything beyond this JSON format.
{{
     "references": [
        {{
            "id": INTEGER: id of the paper,
            "ref": STRING: reference in MLA format,
            "doi": STRING: paper's DOI, if not available, leave empty string
        }},
        // ... additional references ...
        // Each paper should only appear once in the list. The reference id should start with [1] and increment by 1 for each additional reference.
    ],
    "summary": "Your detailed literature review paragraph here, using [id] for citations."
}}
"""),
    ("human", """Query: {query}
Search Results: {search_results}""")
])


HyDE_post_retrieval_xml = ChatPromptTemplate([
    ("system", """1. Create a detailed literature review that directly answers the user's query, following academic writing conventions.
2. Synthesize the information into detailed, informative, and coherent paragraphs that read like a proper literature review section.
3. Highlight key findings and their relevance to answering the query, while maintaining an academic and analytical tone.
4. Use in-text citations `[id]` to link claims to specific papers, as is standard in literature reviews.
5. Structure the review to flow logically, grouping related findings and contrasting different perspectives when relevant.
6. Ensure the summary provides a clear and direct answer to the original query while maintaining the formal style of a literature review.
7. Provide a list of references used in the summary.
8. The writing should be objective and analytical, synthesizing rather than just summarizing individual papers.

Provide the summary in this XML format. You are strictly banned to generate anything beyond this XML format.
<literature_review>
    <references>
        <reference>
            <id>INTEGER: 1, 2, 3, ...</id>
            <ref>STRING: reference in MLA format</ref>
            <doi>STRING: paper's DOI, if not available, leave empty string</doi>
        </reference>
        <!-- ... additional references ... -->
        <!-- Each paper should only appear once in the list. The reference id should start with [1] and increment by 1 for each additional reference. -->
    </references>
    <summary>Your detailed literature review paragraph here, using [id] for citations.</summary>
</literature_review>"""),
    ("human", """Query: {query}
Search Results: {search_results}""")
])



HyDE_post_retrieval_arxiv = ChatPromptTemplate([
    ("system", """You are an AI assistant specializing in summarizing scientific literature. Your task is to create a detailed, informative literature review based on search results."""),
    ("human", """Analyze the following query and search results to produce a brief literature review summary:

Query: {query}
Search Results:
{search_results}

Instructions:
1. Synthesize the information into a single coherent paragraph of about 200 words.
2. Highlight key findings and their relevance to the query.
3. Use in-text citations [id] to link claims to specific papers.
4. Provide a list of references used in the summary.

Provide the summary in this JSON format. You are strictly banned to generate anything beyond this JSON format.
{{
     "references": [
        {{
            "id": INTEGER: id of the paper,
            "ref": STRING: reference in MLA format,
            "doi": STRING: paper's DOI, if not available, leave empty string
        }},
        // ... additional references ...
        // Each paper should only appear once in the list. The reference id should start with [1] and increment by 1 for each additional reference.
    ],
    "summary": "Your detailed literature review paragraph here, using [id] for citations."
}}
""")
])

sql_query_tool_description_2 = """
Function: Executes a SQL query on Google BigQuery.
Output:
1. The header of the result table (top 10 rows). 
2. The file path where the complete result is stored.
Dependencies:
1. Use `sql_get_schema` and `sql_list_table` to retrieve the schema of relevant tables (if necessary).
2. Use `search_name` for accurate name matching if needed (if necessary).

Note: 
1. Ensure your query is well-formed
2. Ensure all tables and columns actually exist in the database

Custom functions:
`SciSciNet_US_V5.TEXT_EMBEDDING` is defined to convert text to embeddings.
`VECTOR_SEARCH` is defined to perform similarity search (Note that the result sub-table is named as `base`).

Example query:
```sql
-- Get papers that are relevant to the search query
SELECT
  vs.base.*, vs.distance
FROM VECTOR_SEARCH(
  TABLE SciSciNet_US_V5.papers,
  "abstract_embedding",
  (SELECT SciSciNet_US_V5.TEXT_EMBEDDING('YOUR SEARCH QUERY')), 
  top_k => NUMBER_OF_RESULTS
) vs
```"""