from langchain.prompts import ChatPromptTemplate
from langchain_core.messages import HumanMessage, SystemMessage


HyDE_pre_retrieval = ChatPromptTemplate([
    ("system", """You are an AI assistant specializing in US energy policy analysis. Your task is to generate hypothetical, relevant paragraphs that might appear in energy policy documents."""),
    ("human", """Create 3 hypothetical paragraphs that could appear in energy policy documents related to the given query:
Query: {query}

Instructions:
1. Generate paragraphs that are concise yet informative, reflecting current energy policy writing styles.
2. You must ensure that the generated paragraphs are likely to fit into policy documents.
3. Consider state-level variations and temporal aspects of energy policies.

Your output must follow this JSON format. You are strictly banned to generate anything beyond this JSON format.
{
    "Section 1": "Detailed content for Section 1...",
    "Section 2": "Detailed content for Section 2...",
    "Section 3": "Detailed content for Section 3..."
}""")
])


HyDE_post_retrieval = ChatPromptTemplate([
    ("system", """1. Create a detailed policy analysis that directly answers the user's query.
2. Synthesize the information into detailed, informative, and coherent paragraphs.
3. Highlight key policy findings and their relevance to answering the query.
4. Use in-text citations `[id]` to link claims to specific policy documents.
5. Ensure the summary provides a clear and direct answer to the original query.
6. Provide a list of references used in the summary.
7. Consider state-level variations and temporal aspects when relevant.

Provide the summary in this JSON format. You are strictly banned to generate anything beyond this JSON format.
{
     "references": [
        {
            "id": INTEGER: id of the policy document,
            "ref": STRING: reference in format "Policy Name (State, Date)",
            "doi": STRING: document's URL if available, otherwise empty string
        },
        // ... additional references ...
        // Each document should only appear once in the list. The reference id should start with [1] and increment by 1 for each additional reference.
    ],
    "summary": "Your detailed policy analysis paragraph here, using [id] for citations."
}
"""),
    ("human", """Query: {query}
Search Results: {search_results}""")
])


HyDE_post_retrieval_xml = ChatPromptTemplate([
    ("system", """1. Create a detailed policy analysis that directly answers the user's query, following policy analysis writing conventions.
2. Synthesize the information into detailed, informative, and coherent paragraphs that read like a proper policy analysis.
3. Highlight key policy findings and their relevance to answering the query, while maintaining an analytical tone.
4. Use in-text citations `[id]` to link claims to specific policy documents, as is standard in policy analysis.
5. Structure the analysis to flow logically, grouping related findings and contrasting different policy approaches when relevant.
6. Ensure the summary provides a clear and direct answer to the original query while maintaining the formal style of a policy analysis.
7. Provide a list of references used in the summary.
8. The writing should be objective and analytical, synthesizing rather than just summarizing individual documents.
9. Consider state-level variations and temporal aspects when relevant.

Provide the summary in this XML format. You are strictly banned to generate anything beyond this XML format.
<policy_analysis>
    <references>
        <reference>
            <id>INTEGER: 1, 2, 3, ...</id>
            <ref>STRING: reference in format "Policy Name (State, Date)"</ref>
            <doi>STRING: document's URL if available, otherwise empty string</doi>
        </reference>
        <!-- ... additional references ... -->
        <!-- Each document should only appear once in the list. The reference id should start with [1] and increment by 1 for each additional reference. -->
    </references>
    <summary>Your detailed policy analysis paragraph here, using [id] for citations.</summary>
</policy_analysis>"""),
    ("human", """Query: {query}
Search Results: {search_results}""")
])


HyDE_post_retrieval_arxiv = ChatPromptTemplate([
    ("system", """You are an AI assistant specializing in analyzing energy policy documents. Your task is to create a detailed, informative policy analysis based on search results."""),
    ("human", """Analyze the following query and search results to produce a brief policy analysis summary:

Query: {query}
Search Results:
{search_results}

Instructions:
1. Synthesize the information into a single coherent paragraph of about 200 words.
2. Highlight key policy findings and their relevance to the query.
3. Use in-text citations [id] to link claims to specific policy documents.
4. Provide a list of references used in the summary.
5. Consider state-level variations and temporal aspects when relevant.

Provide the summary in this JSON format. You are strictly banned to generate anything beyond this JSON format.
{
     "references": [
        {
            "id": INTEGER: id of the policy document,
            "ref": STRING: reference in format "Policy Name (State, Date)",
            "doi": STRING: document's URL if available, otherwise empty string
        },
        // ... additional references ...
        // Each document should only appear once in the list. The reference id should start with [1] and increment by 1 for each additional reference.
    ],
    "summary": "Your detailed policy analysis paragraph here, using [id] for citations."
}
""")
])

sql_query_tool_description_2 = """
Function: Executes a SQL query on Google BigQuery.
Output:
1. The header of the result table (top 10 rows). 
2. The file path where the complete result is stored.
Dependencies:
1. Use `sql_get_schema` and `sql_list_table` to retrieve the schema of relevant tables (if necessary).
2. Use `search_name` for accurate name matching if needed (if necessary).

Note: 
1. Ensure your query is well-formed
2. Ensure all tables and columns actually exist in the database

Custom functions:
`SciSciNet_US_V5.TEXT_EMBEDDING` is defined to convert text to embeddings.
`VECTOR_SEARCH` is defined to perform similarity search (Note that the result sub-table is named as `base`).

Example query:
```sql
-- Get papers that are relevant to the search query
SELECT
  vs.base.*, vs.distance
FROM VECTOR_SEARCH(
  TABLE SciSciNet_US_V5.papers,
  "abstract_embedding",
  (SELECT SciSciNet_US_V5.TEXT_EMBEDDING('YOUR SEARCH QUERY')), 
  top_k => NUMBER_OF_RESULTS
) vs
```"""